**BING DORKER - JEMBUT EDITION DORKER**
<br>
**Python Version 2.7 Bing Dorker File**<br>
**Python Version 3.8 IP BULK JEMBUT EDITION**<br>
**ICQ : icq.im/Jarot**<br>
**[Python Download 2.7 For BING DORKER](https://www.python.org/download/releases/2.7/)**<br>
**[Python Download 3.8 For JEMBUT-EDITION Grabber BUlk IP](https://www.python.org/download/releases/3.0/)**<br>
🖼️ **Screenshotss** 🖼️<br>
**REPORT BUG IN ISSUES**<br>
**[JEMBUT ISSUES](https://github.com/fstreitzia/Bing-Dorker/issues/new)**
<img src="https://scontent-sin6-1.xx.fbcdn.net/v/t1.15752-9/116195177_329625721745638_8857232788391062012_n.png?_nc_cat=104&_nc_sid=b96e70&_nc_eui2=AeH2tGfJRUwxtGq7r7Fkd68gJqMRKTzpGrQmoxEpPOkatHTVrQA71LsILY1hmFLqW23wrW2iX5MMD0FbuuAnqrhs&_nc_ohc=KaqmFrjIK5kAX8-SKyx&_nc_oc=AQkskhz5TQYLlHN5Jea6lg3NL5yOTT1cVGntW2uDECDR1hRDyhq-q5sVsi2CwSuGnlw&_nc_ht=scontent-sin6-1.xx&oh=b7ca5ec4c897fdb95df2564836b7f49e&oe=5F40108B"><center><br>
<img src="https://scontent-sin6-1.xx.fbcdn.net/v/t1.15752-9/116042704_289029275505630_7335972952880635916_n.png?_nc_cat=101&_nc_sid=b96e70&_nc_eui2=AeGpViRryIJHv_3kh5z2VBIvrGweqftsIlKsbB6p-2wiUiZguCjKMCI254OVXGl-BnM7qe6mo4auN0lM6d2TcdGE&_nc_ohc=tZQb6qJs0KQAX9I828p&_nc_ht=scontent-sin6-1.xx&oh=a4df0f7901c7c7942e5b8deff5caaad2&oe=5F402B1F">
<blockquote>git clone https://github.com/fstreitzia/Bing-Dorker.git</blockquote>.
<blockquote>pip install requests</blockquote>.
<blockquote>pip install bs4</blockquote>.
<blockquote>pip install colorama</blockquote>.

| Tools | Bing Dorker | Zone-H Grabber   | Reverse IP  | Grab IP Bulk | 
|---------------------------------- |---------------|---------------|----------------|-----------|
| <ul><li>[x] Download </li></ul>       | <ul><li>[x] Python </li></ul>        | <ul><li>[X] Version </li></ul> | <ul><li>[x] 2.7 </li></ul> | <ul><li>[X] 3.8 </li></ul> |
| <ul><li>[x] Bing Dorker </li></ul>       | <ul><li>[x] URL Reverse </li></ul>        | <ul><li>[x] Zone-H Grabber  </li></ul> | <ul><li>[ ]  </li></ul> | <ul><li>[ ]  </li></ul> |
| <ul><li>[x] Weblist From IP </li></ul>       | <ul><li>[x] Web List To IP</li></ul>        | <ul><li>[x] SMTP Checker </li></ul> | <ul><li>[ ]  </li></ul> | <ul><li>[ ]  </li></ul> |
| <ul><li>[x] IP From Weblist </li></ul>       | <ul><li>[x] IP To Weblist </li></ul>        | <ul><li>[X] Spotify Checker  </li></ul> | <ul><li>[ ]  </li></ul> | <ul><li>[ ]  </li></ul> |
| <ul><li>[x] HTPP Weblist </li></ul>       | <ul><li>[x] Tranacak Ver1</li></ul>        | <ul><li>[ ]  </li></ul> | <ul><li>[ ]  </li></ul> | <ul><li>[ ]  </li></ul> |
| <ul><li>[x] Scanner Clear </li></ul>       | <ul><li>[x] Zone-H Grabber</li></ul>        | <ul><li>[ ]  </li></ul> | <ul><li>[ ]  </li></ul> | <ul><li>[ ]  </li></ul> |
